/*
 * Frame definition
 */
static const GLbyte	frame_position[] =
{
    -1, -1, 0,
	 1, -1, 0,
	 1,  1, 0,
	-1,  1, 0
};

static const GLbyte frame_color[] =
{
	1, 1, 0,
	1, 1, 0,
	1, 1, 0,
	1, 1, 0
};
