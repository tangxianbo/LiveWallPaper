// stdafx.h 

#pragma once

#include "targetver.h"

#define _CRT_SECURE_NO_WARNINGS
#include <assert.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <tchar.h>
#include <errno.h>
#include <string.h>


